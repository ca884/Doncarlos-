const settings = {
  packname: '𝐉ᴜɴᴇ 𝐌ᴅ',
  author: 'SUPREME',
  botName: "𝐉ᴜɴᴇ 𝐌ᴅ",
  botOwner: 'Supreme', // Your name
  ownerNumber: '254798570132', //Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.2.4",
};

module.exports = settings;
